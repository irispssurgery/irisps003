<?
	if(!$mode)
	{
		include "../../CObject.lib";
	}
	else
	{
		/*include "../constant/db_config.def";
		include "../constant/common.def";
		include "../class/CDatabase.class";
		include "../class/CBbs.class";
		include "../class/CBbscode.class";
		include "../class/CPaging.class";
		include "../class/CAdmin.class";
		include "../function/common.func";

		$db = new CDatabase($dbName, $host, $id, $passwd);
		$ins_admin= new CAdmin();*/
	}

	$bbs = new CBbs();

	$is_admin = $ins_admin->isAdmined($user_id);
	
	if($is_admin<=0)
	{
		$writer=$bbs->getWriteName($bbs_idx);

		if($user_name!=$writer)
			Error("�� �Խù��� �ۼ��ڰ� �ƴϽʴϴ�.");
	}

	$result = $bbs->bbsDelete($bbscode_code, $bbs_idx, $is_uploaded_file);

	if(!$result)
		Error("�����ϴ��� ������ �߻��Ͽ����ϴ�.");


	Redirect("../..".$LOCATION."?bbscode_code=".$bbscode_code."&mode=list&site_code=".$site_code."");
?>